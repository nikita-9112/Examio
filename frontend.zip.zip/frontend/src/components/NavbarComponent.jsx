import { Link, useNavigate } from "react-router-dom";

import Button from "./ui/Button";
import { useAuth } from "../context/AuthContext";

const Navbar = () => {

  const {user, logout} = useAuth();
  const navigate = useNavigate();

  const handleLogout = ()=>{
    logout();
    navigate("/");
  }

  const handleDashboard = () =>{
    navigate("/dashboard");
  }


return (
<header
className="
sticky
top-0
z-50
border-b
border-slate-200
bg-white/80
backdrop-blur-md
"
>
<div
className="
mx-auto
flex
max-w-7xl
items-center
justify-between
px-5
py-3
"
>
{/* Logo */}

    <Link
      to="/"
      className="
        text-xl
        font-bold
        text-slate-900
      "
    >
      Examio
    </Link>

    {/* Navigation */}

    <nav
      className="
        hidden
        gap-8
        md:flex
      "
    >
      <Link
        to="/"
        className="
          text-slate-600
          transition
          hover:text-blue-600
        "
      >
        Home
      </Link>

      <Link
        to="/subject-packs"
        className="
          text-slate-600
          transition
          hover:text-blue-600
        "
      >
        SubjectPacks
      </Link>

      <Link
        to="/about"
        className="
          text-slate-600
          transition
          hover:text-blue-600
        "
      >
        About
      </Link>
    </nav>

    {/* Actions */}

{user? 
   <div
   className="
     flex
     items-center
     gap-3
   "
 >
   <span onClick={handleDashboard} className="cursor-pointer">Hi, {user.name}</span>

     <Button size="sm" variant="secondary" onClick={handleLogout}>
       logout
     </Button>
 </div>
: 
<div
className="
  flex
  items-center
  gap-3
"
>
<Link to="/login">
  <Button variant="outline" size="sm">
    Login
  </Button>
</Link>

<Link to="/register">
  <Button size="sm">
    Get Started
  </Button>
</Link>
</div>
}
   


  </div>
</header>

);
};

export default Navbar;